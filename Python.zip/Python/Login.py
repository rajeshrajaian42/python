from tkinter import *
from tkinter import messagebox
import os
import MySQLdb

screen = Tk()
screen.state('zoomed')
screen.title("Login")

width, height = screen.winfo_screenwidth(), screen.winfo_screenheight()
screen.geometry('%dx%d' % (width,height))

def validation():
	username_info = username.get()
	password_info = password.get()
	
	if(username_info=='' and password_info=='' ):
		messagebox.showwarning("Warning","Please Provide User Name & Password")
	elif(username_info==''):
		messagebox.showwarning("Warning","Please Provide User Name")	
	elif(password_info==''):
		messagebox.showwarning("Warning","Please Provide Password")	
	else:
		login()

def login():	
	username_info = username.get()
	password_info = password.get()
		
	db = MySQLdb.connect("localhost","root","admin","test" )

	cursor = db.cursor()
	
	sql = "SELECT * FROM sample where User_Name='"+username_info+"' and Password='"+password_info+"'"

	try:
		cursor.execute(sql)
		results = cursor.fetchall()
	 
		count=0;
		for row in results:		   
			User_Name = row[0]
			Password = row[1]
			age = row[2]
			count=count+1  					 
	except:
		print("Error: unable to fecth data")

	db.close()

	if count!=0:
		screen.withdraw()
		os.system('icon-menu.py')
	else:		
		messagebox.showerror("Login Failed", "Invalid Credential")

def main_screen():	
	C = Canvas(screen, bg="white", height=150, width=300)
	filename = PhotoImage(file = "background2.png")
	background_label = Label(screen, image=filename)
	background_label.place(x=0, y=0, relwidth=1, relheight=1)
	C.pack()

	global username
	global password
	global Txt_1
	global Txt_2

	username = StringVar()
	password = StringVar()

	L1=Label(screen, bg="white", text = "User Name * ")
	L1.config(font=("Agency FB", 24))
	L1.place( x=610, y=141, height=30, width=150)

	Txt_1 = Entry(screen, width="35", border=0, textvariable = username)
	Txt_1.config(font=("Agency FB", 18), justify='center')
	Txt_1.place( x=602, y=190, height=40, width=180)

	L2 = Label(screen, bg="white", text = "Password * ")
	L2.config(font=("Agency FB", 24))
	L2.place( x=610, y=280, height=30, width=150)

	Txt_2 =  Entry(screen, width="35", border=0, textvariable = password, show="*")
	Txt_2.config(font=("Agency FB", 18), justify='center')
	Txt_2.place( x=602, y=340, height=40, width=180)

	photo = PhotoImage(file = r"login_Button2.png") 
	photoimage = photo.subsample(1,1) 

	B1 = Button(screen, image = photoimage, border=0,bg="white", text = "Login",command = validation)
	B1.place( x=618, y=430)

	screen.mainloop()

main_screen()