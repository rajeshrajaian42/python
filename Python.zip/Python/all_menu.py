from tkinter import *
  
screen = Tk() 

Label(screen, text = 'Web Crawling Menu', font =( 
  'Verdana', 15)).pack(side = TOP, pady = 30) 
  
frame = Frame(screen) 
frame.pack() 

bottomframe = Frame(screen) 
bottomframe.pack( side = LEFT ) 
  
photo = PhotoImage(file = r"flipkart1.png") 

photoimage = photo.subsample(1,1) 

photo2 = PhotoImage(file = r"facebook.png") 
 
photoimage2 = photo2.subsample(1,1)

photo3 = PhotoImage(file = r"amazon.png") 
 
photoimage3 = photo3.subsample(1,1)

photo4 = PhotoImage(file = r"wikipedia.png") 
 
photoimage4 = photo4.subsample(1,1)

redbutton = Button(frame, image = photoimage, text = 'Red', fg ='red') 
redbutton.pack( side = LEFT , padx=20, pady=40)

greenbutton = Button(frame, image = photoimage2, text = 'Brown', fg='brown') 
greenbutton.pack( side = LEFT , padx=20, pady=40)

bluebutton = Button(frame, image = photoimage3, text ='Blue', fg ='blue') 
bluebutton.pack( side = LEFT , padx=20, pady=40)

blackbutton = Button(bottomframe, image = photoimage4, text ='Black', fg ='black') 
blackbutton.pack( side = LEFT , padx=20, pady=40)

yellowbutton = Button(bottomframe, image = photoimage4, text ='Black', fg ='black') 
yellowbutton.pack(side = LEFT , padx=20, pady=40)

greybutton = Button(bottomframe, image = photoimage4, text ='Black', fg ='black') 
greybutton.pack(side = LEFT , padx=20, pady=40)

screen.mainloop() 