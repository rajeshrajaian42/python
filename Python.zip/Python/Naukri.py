from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
from fpdf import FPDF
from docx import Document
from docx.shared import Inches
import tkinter.scrolledtext as tkst
import os
import MySQLdb
import time
import urllib.request 
import re
import openpyxl 
import sys

screen = Tk()
screen.state('zoomed')
screen.title("Login")

width, height = screen.winfo_screenwidth(), screen.winfo_screenheight()
screen.geometry('%dx%d' % (width,height))

def main_screen():	
	C = Canvas(screen, bg="white", height=150, width=300)
	filename = PhotoImage(file = "Background_main.png")
	background_label = Label(screen, image=filename)
	background_label.place(x=0, y=0, relwidth=1, relheight=1)
	C.pack()
	
	global Url
	Url = StringVar()
	
	photo = PhotoImage(file = r"Search_Icon.png") 
	photoimage = photo.subsample(1,1) 
	
	photo1 = PhotoImage(file = r"search_bar.png") 
	photoimage1 = photo1.subsample(1,1) 

	L1=Label(screen, bg="white",border=0,text ="Paste url :")
	L1.config(font=("Times New Roman", 24))
	L1.place( x=8, y=30, height=30, width=150)
	
	B1 = Button(screen, image = photoimage, border=0,bg="white", text = "Login",command = validation)
	B1.place( x=1220, y=12)
	
	B2 = Button(screen, image = photoimage, border=0,bg="white", text = "refresh",command= refresh)
	B2.place( x=1150, y=550)
	
	L2=Label(screen, bg="white", image = photoimage1, text = "")
	L2.place( x=160, y=16, height=60, width=1050)
	
	Txt_2 =  Entry(screen, border=0, textvariable =Url)
	Txt_2.config(font=("Agency FB", 14), justify='center')
	Txt_2.place( x=176, y=25, height=40, width=1020)
	
	screen.mainloop()

def refresh():
	screen.destroy()
	os.system('Naukri.py')  

def validation():
	Url_info = Url.get()
	
	if(Url_info==''):
		messagebox.showwarning("Warning","Please Provide the Url in the Search Bar")
	else:			
		Crawl()

def Crawl(): 

	global sample_result
	
	URL_LINK = Url.get()
	
	request_url = urllib.request.urlopen(URL_LINK) 

	content = request_url.read();
	
	content = content.decode('ISO-8859-1')

	sample_pattern = '<ul>[^>]*?<li[^>]*?title\=\"([^>]*?)\"[^>]*?>\s*<a[^>]*?href=\"([^>]*?)\"[^>]*?>[^>]*?(?:<[^>]*?>\s*)+([^>]*?)(?:<[^>]*?>\s*)+([^>]*?)(?:<[^>]*?>\s*)+([^>]*?)(?:<[^>]*?>\s*)+[\w\W]*?<span[^>]*?class\=\"salary\">\s*(?:<[^>]*?>\s*)+(?:[^>]*?(Not\s*disclosed)[^>]*?<[^>]*?>|INR[^>]*?(?:<[^>]*?>\s*)+([^>]*?PA)[^>]*?<[^>]*?>)'

	sample_result = re.findall(sample_pattern, content) 	
	s = "#"
	i=1

	t = tkst.ScrolledText(screen,border=3,padx=50,pady=50,fg="green")

	for x in range(len(sample_result)): 
		i=i+1	
		str = s.join(sample_result[x])
		val = str.split("#")		
		j=1
		t.insert(INSERT, "\n***************************************************\n")
		for y in range(len(val)): 				
			t.insert(INSERT, "   "+val[y])
			t.insert(INSERT, "\n")
			j=j+1
			
	t.pack(side = TOP,fill='y')
				
	Download()
	
def Download():	
	screen.photo3 = PhotoImage(file = r"excel_icon.png") 
	screen.photoimage3 = screen.photo3.subsample(1,1) 
	screen.photo4 = PhotoImage(file = r"pdf_icon.png") 
	screen.photoimage4 = screen.photo4.subsample(1,1)
	screen.photo5 = PhotoImage(file = r"Doc_icon.png") 
	screen.photoimage5 = screen.photo5.subsample(1,1)
	
	L3=Label(screen, bg="white",border=0,text ="Output Formats :")
	L3.config(font=("Times New Roman", 18),fg="Blue")
	L3.place( x=1100, y=140, height=30, width=180)
	
	B3 = Button(screen, image = screen.photoimage3, border=0,bg="white", text = "Login",command = Excel)
	B3.place( x=1145, y=200)

	B4 = Button(screen, image = screen.photoimage4, border=0,bg="white", text = "Login",command = Pdf)
	B4.place( x=1150, y=350)
	
	B5 = Button(screen, image = screen.photoimage5, border=0,bg="white", text = "Login",command = Docx)
	B5.place( x=1142, y=500)
	
	if not os.path.exists('Output'):
		os.makedirs('Output')
		
	messagebox.showinfo("Success", "Crawling Completed...!!")
				
def Pdf():	
	pdf = FPDF()
	pdf.add_page()
	pdf.set_font("Arial", size=12)
	s = "#"
	i=1
	
	for k in range(len(sample_result)): 
		i=i+1	
		str = s.join(sample_result[k])
		val = str.split("#")		
		j=1		
		pdf.cell(200, 10, txt='******************************', ln=1, align="L")
		for m in range(len(val)): 		
			pdf.cell(200, 10, txt=val[m], ln=1, align="L")			
			j=j+1
				
	pdf.output("Output/Flipkart.pdf")
	
	messagebox.showinfo("Success", "Download Completed...!!")
	
	
def Excel():	
	wb = openpyxl.Workbook()  
	sheet = wb.active 	
	s = "#"
	i=1
	
	sheet.cell(row = 1, column = 1).value = ' Mobile Model '
	sheet.cell(row = 1, column = 2).value = ' Rating Star'
	sheet.cell(row = 1, column = 3).value = ' Rating '
	sheet.cell(row = 1, column = 4).value = ' Review '
	sheet.cell(row = 1, column = 5).value = ' RAM & ROM '
	sheet.cell(row = 1, column = 6).value = ' Display '
	sheet.cell(row = 1, column = 7).value = ' Camera '
	sheet.cell(row = 1, column = 8).value = ' Battery '
	sheet.cell(row = 1, column = 9).value = ' Processor '
		
	for n in range(len(sample_result)): 
		i=i+1	
		str = s.join(sample_result[n])
		val = str.split("#")		
		j=1		
		for z in range(len(val)): 		
			sheet.cell(row = i, column = j).value = val[z]						
			j=j+1
			
	sheet.column_dimensions['A'].width = 50
	sheet.column_dimensions['B'].width = 12
	sheet.column_dimensions['C'].width = 20
	sheet.column_dimensions['C'].width = 20
	sheet.column_dimensions['D'].width = 30
	sheet.column_dimensions['E'].width = 50
	sheet.column_dimensions['F'].width = 40
	sheet.column_dimensions['G'].width = 45
	sheet.column_dimensions['H'].width = 40
	sheet.column_dimensions['I'].width = 60
			
	wb.save('Output/Flipkart.xlsx') 
	
	messagebox.showinfo("Success", "Download Completed...!!")
	
def Docx():	

	f = open("Output/Flipkart.txt", "a")
	
	s = "#"
	i=1
		
	for k in range(len(sample_result)): 
		i=i+1	
		str = s.join(sample_result[k])
		val = str.split("#")		
		j=1	
		f.write("******************************\n")
		for Q in range(len(val)): 	
			f.write(val[Q]+ "\n")
			j=j+1
	
	f.close()
	
	messagebox.showinfo("Success", "Download Completed...!!")
		
main_screen()