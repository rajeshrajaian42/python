from tkinter import * 
from tkinter.ttk import *
import sys
import os

global screen
screen = Tk()

screen.geometry("1500x1500")

frame = Frame(screen) 
frame.pack(side = TOP) 

bottomframe = Frame(screen) 
bottomframe.pack( side = LEFT ) 

def Flipkart():
	screen.withdraw()
	os.system('Flipkart.py')
	
def Daily_Thanthi():
	screen.withdraw()
	os.system('daily_thanthi.py')	
 
Label(frame, text = 'Web Crawling Menu', font =( 
  'Verdana', 15)).pack(side = TOP, pady = 30) 
 
photo = PhotoImage(file = r"flipkart_icon.png") 

photo2 = PhotoImage(file = r"daily-thanthi_icon.png") 
 
photoimage = photo.subsample(1,1) 
photoimage2 = photo2.subsample(1,1)

redbutton = Button(frame, image = photoimage, command = Flipkart) 
redbutton.pack( side = LEFT , padx=20, pady=40)

greenbutton = Button(frame, image = photoimage2, command = Daily_Thanthi)
greenbutton.pack( side = LEFT , padx=20, pady=40)

mainloop() 